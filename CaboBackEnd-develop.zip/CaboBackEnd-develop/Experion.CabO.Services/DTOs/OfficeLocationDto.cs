﻿using Experion.CabO.Data.Entities;

namespace Experion.CabO.Services.DTOs
{
    public class OfficeLocationDto
    {
        internal static OfficeLocation office;
        public string Address { get; set; }
    }
}
