﻿namespace Experion.CabO.Services.DTOs
{
    public class OfficeRideDriverInfo
    {
        public int driverId { get; set; }
        public int cabId { get; set; }
        public string driverName { get; set; }
        public string driverPhone { get; set; }
        public string cabName { get; set; }
        public string vehicleNo { get; set; }
    }
}
