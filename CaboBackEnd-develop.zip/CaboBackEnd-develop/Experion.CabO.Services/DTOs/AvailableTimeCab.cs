﻿namespace Experion.CabO.Services.DTOs
{
    public class AvailableTimeCab
    {
        public string availableTime { get; set; }
    }
}
