﻿namespace Experion.CabO.Services.DTOs
{
    public class ProjectDto
    {
        public string ProjectCode { get; set; }
    }
}
