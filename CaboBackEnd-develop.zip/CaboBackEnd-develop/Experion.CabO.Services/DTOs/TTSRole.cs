﻿namespace Experion.CabO.Services.DTOs
{
    public class TTSRole
    {
        public int roleId { get; set; }
        public string roleName { get; set; }
    }
}
