﻿namespace Experion.CabO.Services.DTOs
{
   public  class DriverLoginDto
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
