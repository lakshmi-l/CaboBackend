﻿namespace Experion.CabO.Services.DTOs
{
    public class RatingInfo
    {
        public string rideId { get; set; }
        public float timing { get; set; }
        public float behaviour { get; set; }
        public float overall { get; set; }
        public string comments { get; set; }
    }
}
