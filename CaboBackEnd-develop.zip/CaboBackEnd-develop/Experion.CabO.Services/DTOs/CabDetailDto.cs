﻿namespace Experion.CabO.Services.DTOs
{
    public class CabDetailDto
    {
        public int Id { get; set; }
        public string Model { get; set; }
    }
}
