﻿namespace Experion.CabO.Services.DTOs
{
    public class AssignedOffices
    {
        public int OfficeId { get; set; }
        public string OfficeAddress { get; set; }
    }
}
