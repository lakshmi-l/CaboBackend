﻿namespace Experion.CabO.Services.DTOs
{
    public class ShiftDto
    {
        public int Id { get; set; }
        public string ShiftName { get; set; }
    }
}
