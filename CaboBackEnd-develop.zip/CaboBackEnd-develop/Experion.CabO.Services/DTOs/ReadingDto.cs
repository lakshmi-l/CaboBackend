﻿namespace Experion.CabO.Services.DTOs
{
    public class ReadingDto
    {
        public long reading { get; set; }
    }
}
