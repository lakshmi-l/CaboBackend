﻿namespace Experion.CabO.Services.DTOs
{
    public class CompletedRideInfo
    {
        public string DriverName { get; set; }
        public string CabName { get; set; }
        public float Timing { get; set; }
        public float Behaviour { get; set; }
        public float Overall { get; set; }
        public string Comments { get; set; }
    }
}
