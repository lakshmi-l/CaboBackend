﻿namespace Experion.CabO.Services.DTOs
{
    public class DriverDetails
    {
        public string Name { get; set; }
        public string PhoneNo { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public bool IsDeleted { get; set; }
    }
}

