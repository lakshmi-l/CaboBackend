﻿namespace Experion.CabO.Services.DTOs
{
    public class CabListDto
    {
        public int cabId { get; set; }
        public string cabName { get; set; }
    }
}
