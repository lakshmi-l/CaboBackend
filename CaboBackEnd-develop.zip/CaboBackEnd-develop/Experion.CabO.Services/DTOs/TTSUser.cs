﻿namespace Experion.CabO.Services.DTOs
{
    public class TTSUser
    {
        public int userId { get; set; }
        public int employeeId { get; set; }
        public string email { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string username { get; set; }
        public string project { get; set; }
        public string totalEffort { get; set; }
        public string effort { get; set; }
        public string isShortLogged { get; set; }
    }
}
