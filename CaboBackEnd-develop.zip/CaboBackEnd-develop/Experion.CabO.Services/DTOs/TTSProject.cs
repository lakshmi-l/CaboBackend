﻿namespace Experion.CabO.Services.DTOs
{
    public class TTSProject
    {
        public int projectId { get; set; }
        public string code { get; set; }
        public string description { get; set; }
        public int effort { get; set; }
        public string date { get; set; }
        public string projectEffort { get; set; }
    }
}
