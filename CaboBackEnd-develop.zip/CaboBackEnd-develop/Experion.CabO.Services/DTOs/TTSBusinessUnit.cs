﻿namespace Experion.CabO.Services.DTOs
{
    public class TTSBusinessUnit
    {
        public string businessUnitId { get; set; }
        public string businessUnitName { get; set; }
        public string bussinessHead { get; set; }
    }
}
