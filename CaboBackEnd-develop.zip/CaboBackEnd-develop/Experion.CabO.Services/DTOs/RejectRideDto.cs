﻿namespace Experion.CabO.Services.DTOs
{
    public class RejectRideDto
    {
        public string CancelReason { get; set; }
    }
}
