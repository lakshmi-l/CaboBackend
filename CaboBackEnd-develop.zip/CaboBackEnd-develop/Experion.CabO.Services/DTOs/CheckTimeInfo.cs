﻿using System;

namespace Experion.CabO.Services.DTOs
{
    public class CheckTimeInfo
    {
        public int location1 { get; set; }
        public int location2 { get; set; }
        public DateTime rideTime { get; set; }
        public DateTime rideDate { get; set; }
    }
}
