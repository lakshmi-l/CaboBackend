﻿namespace Experion.CabO.Services.DTOs
{
    public class ApproveRideDto
    {
        public string CabId { get; set; }
        public string CabType { get; set; }
        public string ExternalCabName { get; set; }
    }
}
