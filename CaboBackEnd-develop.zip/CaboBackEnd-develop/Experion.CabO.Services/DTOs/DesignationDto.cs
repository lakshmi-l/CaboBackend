﻿namespace Experion.CabO.Services.DTOs
{
    public class DesignationDto
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}
